var povertyCambodia = [
    {"data": [{"name": "2008", "y": 34.0},
            {"name": "2009", "y": 23.9},
            {"name": "2010", "y": 22.1},
            {"name": "2011", "y": 20.5},
            {"name": "2012", "y": 17.7}
        ]}
];

var povertyMalaysia = [
    {"data": [{"name": "2004", "y": 5.7},
            {"name": "2007", "y": 3.6},
            {"name": "2009", "y": 3.8},
            {"name": "2012", "y": 1.7},
            {"name": "2014", "y": 0.6}
        ]}
];

var povertyThailand = [
    {"data": [{"name": "2010", "y": 16.4},
            {"name": "2011", "y": 13.2},
            {"name": "2012", "y": 12.6},
            {"name": "2013", "y": 10.9},
            {"name": "2014", "y": 10.5}
        ]}
];

var povertyIndonesia = [
    {"data": [{"name": "2010", "y": 13.3},
            {"name": "2011", "y": 12.5},
            {"name": "2012", "y": 12.0},
            {"name": "2013", "y": 11.4},
            {"name": "2014", "y": 11.3}
        ]}
];

var povertyLaos = [
    {"data": [{"name": "1997", "y": 39.1},
            {"name": "2002", "y": 33.5},
            {"name": "2007", "y": 27.6},
            {"name": "2012", "y": 23.2}
        ]}
];

var povertyPhilippines = [
    {"data": [{"name": "2003", "y": 24.9},
            {"name": "2006", "y": 26.6},
            {"name": "2009", "y": 26.3},
            {"name": "2012", "y": 25.2}
        ]}
];

var povertyVietnam = [
    {"data": [{"name": "2010", "y": 20.7},
            {"name": "2012", "y": 17.2},
            {"name": "2014", "y": 13.5}
        ]}
];